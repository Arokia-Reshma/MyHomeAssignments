package baseclass;

public class RandomNumber {

	public static void main(String[] args) {
		 int random=(int)(Math.random()*99999);
		System.out.println(random);

		//0.8850959349161346*999999
		//0.6912398803289648
		
		//37696
		//46105
	}

}
